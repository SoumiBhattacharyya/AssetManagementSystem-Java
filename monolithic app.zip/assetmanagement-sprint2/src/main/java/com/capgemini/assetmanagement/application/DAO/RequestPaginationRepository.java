package com.capgemini.assetmanagement.application.DAO;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.capgemini.assetmanagement.application.entity.Request;

public interface RequestPaginationRepository extends PagingAndSortingRepository<Request, Integer>{
	
	
	
}
