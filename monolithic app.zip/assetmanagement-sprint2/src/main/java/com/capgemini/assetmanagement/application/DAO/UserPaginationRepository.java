package com.capgemini.assetmanagement.application.DAO;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.capgemini.assetmanagement.application.entity.Users;

public interface UserPaginationRepository extends PagingAndSortingRepository<Users, Integer>{

}
