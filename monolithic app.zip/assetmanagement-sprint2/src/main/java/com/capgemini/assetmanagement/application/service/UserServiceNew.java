package com.capgemini.assetmanagement.application.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.capgemini.assetmanagement.application.entity.User;

public interface UserServiceNew {

	public List<User> findAll();

	public Page<User> findAll(int pageNo, int itemsPerPage);

	public Page<User> getSortAssets(int pageNo, int itemsPerPage, String fieldName);

}
