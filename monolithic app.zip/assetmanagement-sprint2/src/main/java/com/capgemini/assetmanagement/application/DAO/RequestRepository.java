package com.capgemini.assetmanagement.application.DAO;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.assetmanagement.application.entity.Request;
import com.capgemini.assetmanagement.application.entity.Requests;

public interface RequestRepository extends JpaRepository<Request, Integer> {

	@Query("from Request where alcUnlc=?1")
	public List<Request> allocatedRequests(String alcUnlc);
	
	@Query("from Request where alcUnlc=?1")
	public List<Request> unallocatedRequests(String alcUnlc);
	
	@Query("from Request where requestId=?1")
	public Request validate(int theId);
	
	@Query("from Requests where requestId=?1")
	public Requests approval(int theId);
	
	@Query("from Requests where requestId=?1")
	public Requests rejection(int theId);

	@Query("from Request where userId=?1 ")
	public List<Request> getUserRequests(Integer theId);
	
	@Query("select r from Request r where r.userId=?1 ")
	public Page<List<Request>> getUserRequests(int theId,Pageable pageable);
	
}
