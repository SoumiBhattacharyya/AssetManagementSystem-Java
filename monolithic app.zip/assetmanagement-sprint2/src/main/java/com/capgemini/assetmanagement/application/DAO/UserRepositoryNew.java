package com.capgemini.assetmanagement.application.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.assetmanagement.application.entity.User;

@Repository
public interface UserRepositoryNew extends JpaRepository<User, Integer> {

}
