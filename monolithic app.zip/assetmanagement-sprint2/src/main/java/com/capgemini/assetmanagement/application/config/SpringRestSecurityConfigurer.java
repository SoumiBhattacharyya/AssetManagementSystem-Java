package com.capgemini.assetmanagement.application.config;
//package com.capgemini.assetmanagement.application.config;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
//import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
//import org.springframework.security.config.http.SessionCreationPolicy;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.web.authentication.AuthenticationFailureHandler;
//import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
//import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
//import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
//import org.springframework.web.filter.OncePerRequestFilter;
//
//import com.capgemini.assetmanagement.application.filter.CustomUsernamePasswordAuthenticationFilter;
//import com.capgemini.assetmanagement.application.handlers.MyLogoutSuccessHandler;
//import com.capgemini.assetmanagement.application.springsecurity.RestAuthenticationEntryPoint;
//
//@Configuration
//@EnableWebSecurity
//@EnableGlobalMethodSecurity(prePostEnabled = true)
//public class SpringRestSecurityConfigurer extends WebSecurityConfigurerAdapter{
//	
//	@Bean
//	public PasswordEncoder getPasswordEncoder() {
//		return new  BCryptPasswordEncoder(12);
//		
//	}
//	
////	@Autowired
//	private RestAuthenticationEntryPoint restAuthenticationEntryPoint;
//	
//	@Bean
//	public RestAuthenticationEntryPoint getRestAuthenticationEntryPoint() {
//		return restAuthenticationEntryPoint;
//	}
//	
//	@Autowired
//	private AuthenticationSuccessHandler authenticationSuccessHandler;
//	
//	@Bean
//	public AuthenticationFailureHandler getAuthenticationFailureHandler() {
//		return new SimpleUrlAuthenticationFailureHandler();
//	}
//	
//	@Autowired
//	private MyLogoutSuccessHandler myLogoutSuccessHandler;
//	
//	@Bean
//	public UsernamePasswordAuthenticationFilter getUsernamePasswordAuthenticationFilter() throws Exception {
//		CustomUsernamePasswordAuthenticationFilter filter = new CustomUsernamePasswordAuthenticationFilter();
//		filter.setAuthenticationSuccessHandler(authenticationSuccessHandler);
//		filter.setAuthenticationFailureHandler(getAuthenticationFailureHandler());
//		filter.setAuthenticationManager(authenticationManager());
//		
//		return filter;
//	}
//	
//	
//
//	
//	@Override
//	protected void configure(HttpSecurity http) throws Exception {
//		http.csrf().disable()
//			.exceptionHandling()
//			.authenticationEntryPoint(restAuthenticationEntryPoint)
//			.and()
//			.authorizeRequests()
//			.antMatchers("/api/get-user/{userId}","/api/edit-users").hasAnyRole("MANAGER","ADMIN")
//			.and()
//			.authorizeRequests()
//			.antMatchers("/api/add-users","/api/delete-user/{userId}").hasRole("ADMIN")
//			.and()
//			.authorizeRequests()
//			.antMatchers("/api/get-users").permitAll()
//			.and()
//			.cors()
//			.and()
//			.addFilterAfter(getUsernamePasswordAuthenticationFilter(), CustomUsernamePasswordAuthenticationFilter.class)
//			.logout()
//			.logoutSuccessHandler(myLogoutSuccessHandler);
//		
//		
//	}
//	
//	
//
//}
