package com.capgemini.assetmanagement.application.DAO;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.assetmanagement.application.entity.User;
import com.capgemini.assetmanagement.application.entity.Users;

public interface UserRepository extends JpaRepository<Users, Integer> {

	@Query("from User where email=?1 ")
	public User findByEmail(String email);

	@Query("from User")
	public List<User> getAllUsers();

	@Query("from User where userId=?1")
	public User getUserById(int theId);

	@Query("from User where role=?1")
	public List<User> getCustomers(String role);

	@Query("from User where userId=?1")
	public User updateUser(int theId);

//	@Query("insert into User (userId,fullName,password,confirmPassword,email,role,mobile,address,userImage) values(:userId,:fullName,:password,:confirmPassword,:email,:role,:mobile,:address,:userImage)")
//	public User addUser(int theId, User user);

}
