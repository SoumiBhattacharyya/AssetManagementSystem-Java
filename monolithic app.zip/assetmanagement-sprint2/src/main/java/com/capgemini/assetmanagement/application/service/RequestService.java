package com.capgemini.assetmanagement.application.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.capgemini.assetmanagement.application.entity.Request;
import com.capgemini.assetmanagement.application.entity.Requests;

public interface RequestService {

	public List<Request> findAll();

	public Request findById(int theId);

	public void save(Request demo);

	public Page<Request> findAll(int pageNo, int itemsPerPage);

	public Page<Request> getSortRequests(int pageNo, int itemsPerPage, String fieldName);

	public void deleteById(int theId);

	public List<Request> allocatedRequests(String alcUnlc);

	public List<Request> unallocatedRequests(String alcUnlc);
	
	public List<Request> getUserRequests(Integer theId);
	
	public Page<List<Request>> getUserRequests(int theId,Pageable pageable);
	
	public Request validate(int theId);
	
	public Requests approval(int theId);
	
	public Requests rejection(int theId);

}
