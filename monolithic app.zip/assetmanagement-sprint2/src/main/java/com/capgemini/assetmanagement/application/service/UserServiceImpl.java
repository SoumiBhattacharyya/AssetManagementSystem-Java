package com.capgemini.assetmanagement.application.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.capgemini.assetmanagement.application.DAO.UserRepository;
import com.capgemini.assetmanagement.application.entity.User;
import com.capgemini.assetmanagement.application.entity.Users;

@Service
public class UserServiceImpl implements UserService {

	private UserRepository userRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	public UserServiceImpl(UserRepository theUserRepository) {
		userRepository = theUserRepository;
	}

//	@Override
//	public List<Users> findAll() {
//		return userRepository.findAll();
//	}

//	@Override
//	public User findById(int theId) {
//		Optional<User> result = userRepository.findById(theId);
//
//		Users theUsers = null;
//
//		if (result.isPresent()) {
//			theUsers = result.get();
//		} else {
//			// we didn't find the employee
//			throw new AssetNotFoundException("Sorry ! No matching results found !");
//		}
//
//		return theUsers;
//	}

	@Override
	public void save(Users theUsers) {
		
		theUsers.setNewPassword(theUsers.getPassword());

		theUsers.setPassword(passwordEncoder.encode(theUsers.getPassword()));
		theUsers.setConfirmPassword(passwordEncoder.encode(theUsers.getConfirmPassword()));
		theUsers.setNewPassword(passwordEncoder.encode(theUsers.getNewPassword()));

		userRepository.save(theUsers);
	}

	@Override
	public void deleteById(int theId) {

		userRepository.deleteById(theId);
	}

	@Override
	public User findByEmail(String email) {

		return userRepository.findByEmail(email);
	}

	@Override
	public List<User> getAllUsers() {
		
		 return userRepository.getAllUsers();
	}

	@Override
	public User getUserById(int theId) {
		
		return userRepository.getUserById(theId);
	}

	@Override
	public List<User> getCustomers(String role) {
		
		return userRepository.getCustomers(role);
	}

	@Override
	public User updateUser(int theId) {
		
		return userRepository.updateUser(theId);
	}

//	@Override
//	public Page<Users> getUser(int pageNo, int itemsPerPage) {
//		Pageable pageable = PageRequest.of(pageNo, itemsPerPage);
//
//		return userRepository.findAll(pageable);
//	}
//
//	@Override
//	public Page<Users> getSortUsers(int pageNo, int itemsPerPage, String fieldName) {
//		Pageable pageable = PageRequest.of(pageNo, itemsPerPage, Sort.by(fieldName));
//
//		return userRepository.findAll(pageable);
//	}

//	@Override
//	public User addUser(int theId, User user) {
//		
//		return userRepository.addUser(theId, user);
//	}

}
