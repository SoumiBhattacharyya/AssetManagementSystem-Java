package com.capgemini.assetmanagement.application.controller;

import java.util.List;
import org.apache.log4j.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.assetmanagement.application.entity.Assets;
import com.capgemini.assetmanagement.application.entity.JwtResponse;
import com.capgemini.assetmanagement.application.entity.User;
import com.capgemini.assetmanagement.application.entity.UserResponse;
import com.capgemini.assetmanagement.application.entity.Users;
import com.capgemini.assetmanagement.application.exception.UserNotFoundException;
import com.capgemini.assetmanagement.application.service.JwtTokenUtil;
import com.capgemini.assetmanagement.application.service.UserService;

import jdk.nashorn.internal.runtime.FindProperty;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class UserRestController {

	Logger log = LogManager.getLogger(UserRestController.class);

	private UserService userService;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private UserDetailsService userDetailsService;

	@PostMapping("/login")
	public ResponseEntity<?> generateAuthenticationToken(@RequestBody Users users) throws Exception {
		try {
			authenticationManager
					.authenticate(new UsernamePasswordAuthenticationToken(users.getEmail(), users.getPassword()));

		} catch (DisabledException de) {
			log.info("User is disabled");
			throw new Exception("USER_DISABLED", de);
		} catch (BadCredentialsException bce) {
			log.info("Invalid Credentials !");
			throw new Exception("INVALID_CREDENTIALS", bce);
		} // end of try catch

		final UserDetails userDetails = userDetailsService.loadUserByUsername(users.getEmail());
		final String email = users.getEmail();

		User users1 = userService.findByEmail(users.getEmail());
		String role = users1.getRole();
		Integer userId = users1.getUserId();

		final String jwt = jwtTokenUtil.generateToken(userDetails);

		return ResponseEntity.ok(new JwtResponse(jwt, email, role, false, userId));

	}

	@Autowired
	public UserRestController(UserService theUserService) {
		userService = theUserService;
	}

	@GetMapping("/get-users")
	public UserResponse<List<User>> getAllUsers() {
		List<User> list = userService.getAllUsers();
		if (list != null) {
			return new UserResponse<List<User>>(false, "Users found!", list, null);
		} else {
			return new UserResponse<List<User>>(true, "Users Not found!", null, null);
		}

	}

	@GetMapping("/get-user/{userId}")
	public UserResponse<Users> getUser(@PathVariable int userId) {

		User theUsers = userService.getUserById(userId);

		if (theUsers != null) {
			return new UserResponse<Users>(false, "User found!", null, null);
		} else {
			return new UserResponse<Users>(true, "User Not found!", null, null);
		}
	}

	@PostMapping("/add-users")
	public UserResponse<User> addUsers(@RequestBody Users theUsers) {

		// also just in case they pass an id in JSON ... set id to 0
		// this is to force a save of new item ... instead of update

//		User demo = userService.getUserById(userId);

		theUsers.getEmail();

		theUsers.setUserId(0);

		theUsers.setNewPassword(theUsers.getPassword());
		userService.save(theUsers);

		return new UserResponse<User>(false, "Users Added Successfully!", null, null);

	}

	@PutMapping("/edit-users")
	public UserResponse<User> updateUser(@RequestBody Users theUsers) {

		User demo = userService.getUserById(theUsers.getUserId());

		if (passwordEncoder.matches(theUsers.getNewPassword(), demo.getPassword())) {

			theUsers.getPassword();
			System.out.println(theUsers.getPassword());

			theUsers.getConfirmPassword();
			System.out.println(theUsers.getConfirmPassword());

			theUsers.setPassword(theUsers.getPassword());
			theUsers.setConfirmPassword(theUsers.getConfirmPassword());

		}

		theUsers.setNewPassword(null);

		userService.save(theUsers);

		return new UserResponse<User>(false, "User updated  !", null, null);

	}

	@DeleteMapping("/delete-user/{userId}")
	public UserResponse<Users> deleteUser(@PathVariable int userId) {

		User tempUsers = userService.getUserById(userId);

		// throw exception if null

		if (tempUsers != null) {
			userService.deleteById(userId);
			return new UserResponse<Users>(false, "User Deleted Successfully!", null, null);
		} else {
			throw new UserNotFoundException("User to be deleted is not found!");

		}
	}

	@GetMapping("/users/get/{email}")
	public UserResponse<User> getCustomerByEmail(@PathVariable String email) {

		User demo = userService.findByEmail(email);
		if (demo == null) {
			return new UserResponse<User>(true, "Invalid email id!", null, null);
		} else {
			return new UserResponse<User>(false, "User found !", null, demo);
		}
	}

	@GetMapping("/get-customers/{role}")
	public UserResponse<List<User>> getCustomers(@PathVariable String role) {

		List<User> demo = userService.getCustomers(role);
		if (demo == null) {
			return new UserResponse<List<User>>(true, "No users found with matching role !", null, null);
		} else {
			return new UserResponse<List<User>>(true, " Customer found !", demo, null);
		}
	}

//	@GetMapping("/users/{pageNo}/{itemsPerPage}")
//	public Page<Users> getUser(@PathVariable int pageNo, @PathVariable int itemsPerPage) {
//		return userService.getUser(pageNo, itemsPerPage);
//	}
//
//	@GetMapping("/users/{pageNo}/{itemsPerPage}/{fieldName}")
//	public Page<Users> getSortUsers(@PathVariable int pageNo, @PathVariable int itemsPerPage,
//			@PathVariable String fieldName) {
//		return userService.getSortUsers(pageNo, itemsPerPage, fieldName);
//	}
}
