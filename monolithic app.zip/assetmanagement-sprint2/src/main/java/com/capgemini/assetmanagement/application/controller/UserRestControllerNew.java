package com.capgemini.assetmanagement.application.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.assetmanagement.application.entity.User;
import com.capgemini.assetmanagement.application.entity.UserResponse;
import com.capgemini.assetmanagement.application.service.UserServiceNew;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class UserRestControllerNew {

	@Autowired
	private UserServiceNew userServiceNew;

	@GetMapping("/users")
	public UserResponse<List<User>> findAll() {
		List<User> list = userServiceNew.findAll();

		if (list != null) {
			return new UserResponse<List<User>>(false, "Users found!", list, null);
		} else {
			return new UserResponse<List<User>>(true, "Users Not found!", null, null);
		}

	}

	@GetMapping("/users/{pageNo}/{itemsPerPage}")
	public Page<User> getUsers(@PathVariable int pageNo, @PathVariable int itemsPerPage) {
		return userServiceNew.findAll(pageNo, itemsPerPage);
	}

	@GetMapping("/users/{pageNo}/{itemsPerPage}/{fieldName}")
	public Page<User> getSortUsers(@PathVariable int pageNo, @PathVariable int itemsPerPage,
			@PathVariable String fieldName) {
		return userServiceNew.getSortAssets(pageNo, itemsPerPage, fieldName);
	}

}
