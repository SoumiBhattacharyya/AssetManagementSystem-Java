package com.capgemini.assetmanagement.application.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.capgemini.assetmanagement.application.DAO.UserRepositoryNew;
import com.capgemini.assetmanagement.application.entity.User;

@Service
public class UserServiceNewImpl implements UserServiceNew {

	private UserRepositoryNew userRepositoryNew;

	@Autowired
	public UserServiceNewImpl(UserRepositoryNew theUserRepositoryNew) {
		userRepositoryNew = theUserRepositoryNew;
	}

	@Override
	public List<User> findAll() {

		return userRepositoryNew.findAll();
	}

	@Override
	public Page<User> findAll(int pageNo, int itemsPerPage) {
		Pageable pageable = PageRequest.of(pageNo, itemsPerPage);
		return userRepositoryNew.findAll(pageable);
	}

	@Override
	public Page<User> getSortAssets(int pageNo, int itemsPerPage, String fieldName) {

		Pageable pageable = PageRequest.of(pageNo, itemsPerPage, Sort.by(fieldName));

		return userRepositoryNew.findAll(pageable);
	}

}
