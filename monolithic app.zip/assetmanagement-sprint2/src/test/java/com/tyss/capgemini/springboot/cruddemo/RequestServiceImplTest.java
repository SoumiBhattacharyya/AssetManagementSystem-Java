package com.tyss.capgemini.springboot.cruddemo;

import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.capgemini.assetmanagement.application.entity.Request;
import com.capgemini.assetmanagement.application.entity.Requests;
import com.capgemini.assetmanagement.application.service.AssetService;
import com.capgemini.assetmanagement.application.service.RequestService;
import com.capgemini.assetmanagement.application.service.UserService;

@SpringBootTest
public class RequestServiceImplTest {

	

	@Autowired
	private RequestService requestService;
	
	Request request;
	Requests theRequests;
	
	@Autowired
	private AssetService assetService;
	
	@Autowired
	private UserService userService;

	@BeforeEach
	void save() {
		request = new Request();
		request.setRequestId(0);
		request.setAssetId(101);
		request.setAssetName("Guitar");
		request.setAssetQuantity(23);
		request.setEmployeeId(122);

		requestService.save(request);
	}

	@Test
	void addRequest() {
		assertNotNull(request);
	}
	@Test
	void getAllRequest() {
		List<Request> demo = requestService.findAll();
		assertNotNull(demo);
	}
	
	@Test
	void searchByIdTest() {
		requestService.findById(request.getRequestId());
	}
	
	@Test
	void deleteByIdTest() {
		requestService.deleteById(request.getRequestId());
	}
	@Test
	void validate() {
		requestService.validate(request.getAssetId());
	}
	@Test
	void approval() {
		requestService.approval(request.getAssetId());
	}
	@Test
	void rejection() {
		requestService.rejection(request.getAssetId());
	}
	@Test
	void allocatedRequest() {
		requestService.allocatedRequests("Allocated");
	}
	@Test
	void unallocatedRequest() {
		requestService.unallocatedRequests("Un-allocated");
	}
	
	void getUserRequests() {
		requestService.getUserRequests(request.getUserId());
	}

}
